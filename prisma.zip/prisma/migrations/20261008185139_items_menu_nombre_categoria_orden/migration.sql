BEGIN;
LOCK TABLE public.menu_item IN ACCESS EXCLUSIVE MODE;
ALTER TABLE public.menu_item ADD COLUMN nombre VARCHAR(255);
ALTER TABLE public.menu_item ADD COLUMN categoria_id BIGINT;
-- Los registros históricos conservan su ruta. Asignar categoría al editarlos.
UPDATE public.menu_item
SET nombre = LEFT(COALESCE(NULLIF(INITCAP(REPLACE(REGEXP_REPLACE(TRIM(BOTH '/' FROM ruta), '^.*/', ''), '-', ' ')), ''), 'Ítem ' || id::text), 255);
ALTER TABLE public.menu_item ALTER COLUMN nombre SET NOT NULL;
ALTER TABLE public.menu_item ALTER COLUMN orden SET DEFAULT 1;
WITH posiciones AS (
  SELECT id, ROW_NUMBER() OVER (PARTITION BY menu_id ORDER BY orden, id)::integer AS nuevo_orden
  FROM public.menu_item WHERE eliminado_en IS NULL
)
UPDATE public.menu_item AS item SET orden = posiciones.nuevo_orden
FROM posiciones WHERE item.id = posiciones.id;
UPDATE public.menu_item SET orden = GREATEST(1, COALESCE(orden, 1)) WHERE eliminado_en IS NOT NULL;
-- Las posiciones negativas solo se usan durante el intercambio dentro de una transacción.
CREATE UNIQUE INDEX menu_item_menu_orden_vigente_key
ON public.menu_item (menu_id, orden) WHERE eliminado_en IS NULL AND orden > 0;
COMMIT;
